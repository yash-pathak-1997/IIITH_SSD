Problem 1

Commands:
	chmod +x q1.sh
	./q1.sh


Problem 2

Commands:
	chmod +x q2.sh
	./q2.sh

# Also used apg library to generate string
sudo apt-get install apg


Problem 3

Commands:
	chmod +x q3.sh
	./q3.sh


Problem 4

Commands:
	chmod +x q4.sh
	./q4.sh


Problem 5

Commands:
	chmod +x q5.sh
	./q5.sh 
